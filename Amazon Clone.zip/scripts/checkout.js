let checkoutHTML = '';
let total = 0;
let beforeTax = 0;
let tax = 0;

function getCartFromStorage() {
  const cartData = localStorage.getItem('cart');
  return cartData ? JSON.parse(cartData) : [];
}


function renderCart(cartData) {
  cartData.forEach((item) => {
    checkoutHTML += `       
   <div class="cart-item-container">

            <div class="cart-item-details">
              <div class="product-name">
                ${item.name}
              </div>
              <div class="product-price">
                R${item.price}
              </div>
              <div class="product-quantity">
                <span>
                  Quantity: <span class="quantity-label">${item.quantity}</span>
                </span>
                <span class="update-quantity-link link-primary">
                  Update
                </span>
                <span class="delete-quantity-link link-primary">
                  Delete
                </span>
              </div>
            </div>

            <br>

            <div class="delivery-options">
              <div class="delivery-options-title">
                Choose a delivery option:
              </div>
              <div class="delivery-option">
                <input type="radio" checked class="delivery-option-input" name="delivery-option-1">
                <div>
                  <div class="delivery-option-date">
                    Whenever
                  </div>
                  <div class="delivery-option-price">
                    Free
                  </div>
                </div>
              </div>
              <div class="delivery-option">
                <input type="radio" class="delivery-option-input" name="delivery-option-1">
                <div>
                  <div class="delivery-option-date">
                    Tomorrow
                  </div>
                  <div class="delivery-option-price">
                    Free
                  </div>
                </div>
              </div>
              <div class="delivery-option">
                <input type="radio" class="delivery-option-input" name="delivery-option-1">
                <div>
                  <div class="delivery-option-date">
                    Today
                  </div>
                  <div class="delivery-option-price">
                    Free
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>`;
  });

  cartData.forEach((item) => {
    total += parseFloat(item.price);
  })
  tax = (total * 0.15);
  const afterTax = total + tax;

  document.querySelector('.js-tax').innerHTML = `R ${tax.toFixed(2)}`;
  document.querySelector('.js-btax').innerHTML = 'R ' + total;
  document.querySelector('.js-items').innerHTML = 'R ' + total;
  document.querySelector('.js-total').innerHTML = `R ${afterTax.toFixed(2)}`;

  document.querySelector('.js-summary').innerHTML = checkoutHTML;

}

document.addEventListener('DOMContentLoaded', function () {
  renderCart(getCartFromStorage());
})


